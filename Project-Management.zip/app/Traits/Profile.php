<?php

namespace App\Traits;

trait Profile
{
    public $first_name;
    public $last_name;
    public $position_name;
    public $country_name;
    public $permanent_address;
    public $phone_number;
    public $email;
    public $account_id;

    public $employee_id;

}
