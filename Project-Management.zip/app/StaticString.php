<?php

namespace App;

class StaticString
{
    const SESSION_ISLOGIN = 'SESSION_ISLOGIN';
    const ACCOUNT_ID = 'ACCOUNT_ID';
    const PERMISSION = 'PERMISSION';
    const POSITION = 'POSITION';
}
