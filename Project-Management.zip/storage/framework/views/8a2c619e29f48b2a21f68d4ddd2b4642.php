<?php $__env->startSection('title', $title); ?>



<?php $__env->startSection('head'); ?>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="pagetitle">
    <h1>Recognitions</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(action('App\Http\Controllers\DashboardController@getViewDashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Recognitions</li>
        </ol>
    </nav>
</div>

<div class="section recognition">
    <div class="card">
        <div class="card-header">
            <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addRecognitionModal">Add</button>
        </div>
        <div class="card-body">
            <table id="recognitionTable" class="display">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Employee Code</th>
                    <th scope="col">Employee Name</th>
                    <th scope="col">Recognition</th>
                    <th scope="col">Recognition Date</th>
                    <th scope="col">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $recognitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recognition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="col"><?php echo e($recognition->recognition_id); ?></th>
                        <th scope="col"><?php echo e($recognition->employee_code); ?></th>
                        <th scope="col"><?php echo e($recognition->last_name); ?> <?php echo e($recognition->first_name); ?></th>
                        <th scope="col"><?php echo e($recognition->recognition_type_name); ?></th>
                        <th scope="col"><?php echo e($recognition->recognition_date); ?></th>
                        <td>
                            <button data-attendance="<?php echo e($recognition->recognition_id); ?>" class="btn btn-primary text-white" onclick="viewAttendanceByID(this)"><i class="bi bi-pencil-square"></i></button>
                            <button data-attendance="<?php echo e($recognition->recognition_id); ?>" class="btn btn-danger text-white" onclick="deleteAttendanceByID(this)" ><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade md1" id="addRecognitionModal" tabindex="-1" aria-labelledby="addRecognitionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addProjectModalLabel">Add new recognition</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!-- Form trong view -->
            <div class="modal-body">
                <form id="recognitionForm">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <label for="employee_id" class="form-label">Employee Name</label>
                            <select class="form-select name1" name="employee_id" id="employee_id" required>
                                <option value="-1">No select</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->employee_id); ?>"><?php echo e($employee->employee_code); ?>

                                        - <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-12" style="margin-top: 1rem">
                            <label for="recognition_types">Recognition Types</label>
                            <select class="form-select name1" name="recognition_type_id" id="recognition_type_id" required>
                            <?php $__currentLoopData = $recognition_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($type->recognition_type_id); ?>'><?php echo e($type->recognition_type_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-12" style="margin-top: 1rem">
                            <label>Recognition Date</label>
                            <input type="date" name="recognition_date" id="recognition_date" class="form-control">
                        </div>
                        <div class="col-md-12" style="margin-top: 1rem">
                            <label for="recognition_description" class="form-label">Description</label>
                            <textarea name="description" id="description" rows="2" class="form-control"></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" id="btnRecognitionSubmit">Submit</button>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var table = $('#recognitionTable').DataTable({
        responsive: true,
        dom: '<"d-flex justify-content-between align-items-center mt-2 mb-2"<"mr-auto"l><"d-flex justify-content-center mt-2 mb-2"B><"ml-auto mt-2 mb-2"f>>rtip',
        buttons: [{
            extend: 'csv',
            className: 'btn btn-primary',
            exportOptions: {
                columns: ':not(:last-child)'
            },
            customize: function (csv) {
                return "\uFEFF" + csv;
            }
        },
            {
                extend: 'excelHtml5',
                className: 'btn btn-primary',
                exportOptions: {
                    columns: ':not(:last-child)'
                },
            },
            {
                extend: 'pdf',
                className: 'btn btn-primary',
                exportOptions: {
                    columns: ':not(:last-child)'
                }
            },
            {
                extend: 'print',
                className: 'btn btn-primary',
                exportOptions: {
                    columns: ':not(:last-child)'
                }
            }
        ],
        lengthMenu: [10, 25, 50, 100, -1],
        pageLength: 10
    });
    $('.dt-search').addClass('d-flex align-items-center');
    $('.dt-search label').addClass('d-flex align-items-center');
    $('.dt-search input').addClass('form-control ml-2');

    document.getElementById('btnRecognitionSubmit').addEventListener('click', function (event) {
        let form = document.getElementById('recognitionForm');
        let formData = new FormData(form);

        console.log(formData);

        fetch('<?php echo e(route('recognition.add')); ?>', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message, "Lưu thành công");
                setTimeout(function () {
                    location.reload();
                }, 500);
            } else {
                // console.log(data);
                let errorMessage = data.message;
                if (data.error) {
                    errorMessage += ': ' + data.error;
                    console.error('Error:', data.error);  // Log lỗi cụ thể ra console
                }
                toastr.error(errorMessage, "Thao tác thất bại");
            }
        })
        .catch(error => {
            console.error('Error:', error);  // Log lỗi mạng hoặc lỗi khác ra console
            toastr.error('Có lỗi xảy ra. Vui lòng thử lại sau.', "Thao tác thất bại");
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/recognition/recognition.blade.php ENDPATH**/ ?>