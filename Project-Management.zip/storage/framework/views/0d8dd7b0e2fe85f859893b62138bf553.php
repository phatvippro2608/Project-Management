<?php $__env->startSection('contents'); ?>
    <div class="card">
        <div class="card-body">























            <div class="row mt-3 ">
                <div class="col-md-3">
                    <input accept=".xlsx" name="file-excel" type="file" class="form-control">
                    <br>
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn btn-primary btn-import">Import</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('.btn-import').click(function (){
            var fileInput = $('input[name="file-excel"]')[0].files[0];
            var formData = new FormData();
            formData.append('file-excel', fileInput);
            $.ajax({
                url: `<?php echo e(action('App\Http\Controllers\AccountController@import')); ?>`,
                type: "POST",
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                contentType: false,
                processData: false,
                success: function(result) {
                    result = JSON.parse(result);
                    if (result.status === 200) {
                        alert('Import thành công')
                    } else {
                        toastr.error(result.message, "Import thất bại");
                    }
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/account/account_import_demo.blade.php ENDPATH**/ ?>