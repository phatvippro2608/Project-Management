<?php $__env->startSection('contents'); ?>
    <div class="pagetitle">
        <h1>Application</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Application</li>
            </ol>
        </nav>
    </div>
    <div class="row gx-3 my-3">
        <div class="col-md-6 m-0">
            <button class="btn btn-primary me-2" id="addApplicationBtn" data-bs-toggle="modal"
                    data-bs-target="#addApplicationModal">
                <i class="bi bi-plus-lg me-2"></i> Add Application
            </button>
            <button class="btn btn-success mx-2" id="exportExcelBtn">
                <i class="bi bi-file-earmark-spreadsheet me-2"></i>Excel
            </button>
        </div>
    </div>
    <div class="card p-2 rounded-4 border">
        <div class="card-header py-0">
            <div class="card-title my-3 p-0">Application List</div>
        </div>
        <div class="card-body">
            <table id="applicationTable" class="table table-hover table-borderless">
                <thead class="table-light">
                <tr>
                    <th>Employee Name</th>
                    <th>PIN</th>
                    <th>Leave Type</th>
                    <th>Apply Type</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Duration</th>
                    <th>Leave Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->employee->first_name); ?> <?php echo e($item->employee->last_name); ?></td>
                        <td><?php echo e($item->employee->employee_code); ?></td>
                        <td><?php echo e($item->leaveType->leave_type); ?></td>
                        <td><?php echo e($item->apply_date); ?></td>
                        <td><?php echo e($item->start_date); ?></td>
                        <td><?php echo e($item->end_date); ?></td>
                        <td><?php echo e($item->duration); ?> days</td>
                        <td><?php echo e($item->leave_status); ?></td>
                        <td>
                            <button
                                class="btn p-0 btn-primary border-0 bg-transparent text-primary shadow-none edit-btn"
                                data-id="<?php echo e($item->id); ?>">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            |
                            <button
                                class="btn p-0 btn-primary border-0 bg-transparent text-danger shadow-none delete-btn"
                                data-id="<?php echo e($item->id); ?>">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Application Modal -->
    <div class="modal fade" id="addApplicationModal" tabindex="-1" aria-labelledby="addApplicationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addApplicationModalLabel">Add New Application</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addApplicationForm">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Employee Name</label>
                            
                            <select class="form-select" aria-label="Default" name="employee_id">
                                <option value="">No select</option>
                                <?php $__currentLoopData = $employee_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->employee_id); ?>"><?php echo e($item->employee_code); ?>

                                        - <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="start_date" class="form-label">PIN</label>
                            <input type="text" class="form-control" id="pin" name="pin" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">Leave Type</label>
                            
                            <select class="form-select" aria-label="Default" name="leave_type">
                                <option value="">No select</option>
                                <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->leave_type_id); ?>"><?php echo e($item->leave_type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">Apply Date</label>
                            <input type="date" class="form-control" id="apply_date" name="apply_date" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" required>
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" required>
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">Duration</label>
                            <input type="text" class="form-control" id="duration" name="duration" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="days" class="form-label">Leaves Status</label>
                            <input type="number" class="form-control" id="leave_status" name="leave_status" readonly>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="editApplicationModal" tabindex="-1" aria-labelledby="editApplicationModal"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editApplicationModalLabel">Edit Application</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editApplicationForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="edit_employee_id" class="form-label">Employee Name</label>
                            <select class="form-select" aria-label="Default" name="employee_id" id="edit_employee_id">
                                <option value="">No select</option>
                                <?php $__currentLoopData = $employee_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->employee_id); ?>"><?php echo e($item->employee_code); ?> -
                                        <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_pin" class="form-label">PIN</label>
                            <input type="text" class="form-control" id="edit_pin" name="pin" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="edit_leave_type" class="form-label">Leave Type</label>
                            <select class="form-select" aria-label="Default" name="leave_type" id="edit_leave_type">
                                <option value="">No select</option>
                                <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->leave_type_id); ?>"><?php echo e($item->leave_type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_apply_date" class="form-label">Apply Date</label>
                            <input type="date" class="form-control" id="edit_apply_date" name="apply_date" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="edit_start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="edit_start_date" name="start_date" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="edit_end_date" name="end_date" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_duration" class="form-label">Duration</label>
                            <input type="text" class="form-control" id="edit_duration" name="duration" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="edit_leave_status" class="form-label">Leave Status</label>
                            <input type="text" class="form-control" id="edit_leave_status" name="leave_status"
                                readonly>
                        </div>
                        <button type="submit" class="btn btn-primary">Edit Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#applicationTable').DataTable({
                language: { search: "" },
                initComplete: function (settings, json) {
                    $('.dt-search').addClass('input-group');
                    $('.dt-search').prepend(`<button class="input-group-text bg-secondary-subtle border-secondary-subtle rounded-start-4">
                                <i class="bi bi-search"></i>
                            </button>`)
                },
                responsive: true
            });

            $('#addApplicationForm').submit(function(e) {
                e.preventDefault();

                $.ajax({
                    url: '<?php echo e(route('leave-application.add')); ?>',
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        if (response.success) {
                            $('#addApplicationModal').modal('hide');
                            toastr.success(response.message, "Successful");
                            setTimeout(function() {
                                location.reload()
                            }, 500);
                        } else {
                            toastr.error(response.message, "Error");
                        }
                    },
                    error: function(xhr) {
                        if (xhr.status === 400) {
                            var response = xhr.responseJSON;
                            toastr.error(response.message, "Error");
                        } else {
                            toastr.error("An error occurred", "Error");
                        }
                    }
                });
            });

            $('#applicationTable').on('click', '.edit-btn', function() {
                var applicationID = $(this).data('id');

                $('#editApplicationForm').data('id', applicationID);
                var url = "<?php echo e(route('leave-application.edit', ':id')); ?>";
                url = url.replace(':id', applicationID);
                $.ajax({
                    url: url,
                    method: 'GET',
                    success: function(response) {
                        var data = response.leave_app;
                        $('#edit_employee_id').val(data.employee_id);
                        $('#edit_pin').val(data.employee.employee_code);
                        $('#edit_leave_type').val(data.leave_type.id);
                        $('#edit_apply_date').val(data.apply_date);
                        $('#edit_start_date').val(data.start_date);
                        $('#edit_end_date').val(data.end_date);
                        $('#edit_duration').val(data.duration);
                        $('#edit_leave_status').val(data.leave_status);
                        $('#editApplicationModal').modal('show');
                    },
                    error: function(xhr) {}
                });
            });


            $('#editApplicationForm').submit(function(e) {
                e.preventDefault();
                var applicationID = $(this).data('id'); // Lấy ID từ form
                var url = "<?php echo e(route('leave-application.update', ':id')); ?>";
                url = url.replace(':id', applicationID);

                $.ajax({
                    url: url,
                    method: 'PUT',
                    data: $(this).serialize(),
                    success: function(response) {
                        if (response.success) {
                            $('#editApplicationModal').modal('hide');
                            $('#successModal').modal('show');
                            toastr.success(response.response, "Edit successful");
                            setTimeout(function() {
                                location.reload()
                            }, 500);
                        }
                    },
                    error: function(xhr) {
                        toastr.error("Error");
                    }
                });
            });

            $('#applicationTable').on('click', '.delete-btn', function() {
                var applicationID = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        var url = "<?php echo e(route('leave-application.destroy', ':id')); ?>";
                        url = url.replace(':id', applicationID);
                        $.ajax({
                            url: url,
                            method: 'DELETE',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>'
                            },
                            success: function(response) {
                                if (response.success) {
                                    toastr.success(response.message,
                                        "Deleted successfully");
                                    setTimeout(function() {
                                        location.reload()
                                    }, 500);
                                } else {
                                    toastr.error("Failed to delete holiday.",
                                        "Operation Failed");
                                }
                            },
                            error: function(xhr) {
                                toastr.error("An error occurred.", "Operation Failed");
                            }
                        });
                    }
                });
            });

            function addDateValidation(startDateInput, endDateInput, daysInput) {
                function calculateDays() {
                    const startDate = new Date(startDateInput.value);
                    const endDate = new Date(endDateInput.value);

                    if (startDate && endDate && startDate <= endDate) {
                        const timeDiff = endDate.getTime() - startDate.getTime();
                        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
                        daysInput.value = daysDiff;

                        endDateInput.setAttribute('min', startDateInput.value);
                    } else {
                        daysInput.value = '';
                        endDateInput.removeAttribute('min');
                    }
                }

                function validateDates() {
                    const startDate = new Date(startDateInput.value);
                    const endDate = new Date(endDateInput.value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0); // Set time to midnight for accurate comparison

                    if (startDate < today) {
                        toastr.error("Start date cannot be before today", "Error");
                        startDateInput.value = '';
                        daysInput.value = '';
                        endDateInput.removeAttribute('min');
                        return;
                    }

                    if (endDate < startDate) {
                        endDateInput.value = startDateInput.value;
                    }

                    calculateDays();
                }

                startDateInput.addEventListener('change', validateDates);
                endDateInput.addEventListener('change', validateDates);

                startDateInput.addEventListener('input', validateDates);
                endDateInput.addEventListener('input', validateDates);
            }

            addDateValidation(
                document.getElementById('start_date'),
                document.getElementById('end_date'),
                document.getElementById('duration')
            );

            addDateValidation(
                document.getElementById('edit_start_date'),
                document.getElementById('edit_end_date'),
                document.getElementById('edit_duration')
            );
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/buttons/2.1.1/css/buttons.dataTables.min.css">
    <script type="text/javascript" charset="utf8"
        src="https://cdn.datatables.net/buttons/2.1.1/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.flash.min.js">
    </script>
    <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
    </script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.html5.min.js">
    </script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.print.min.js">
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/leave/leave-application.blade.php ENDPATH**/ ?>