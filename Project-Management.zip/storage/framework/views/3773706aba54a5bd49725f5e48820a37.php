<?php $__env->startSection('head'); ?>
    <style>
        .card:hover {
            transform: scale(1.05);
            transition: transform 0.2s ease-in-out;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            cursor: pointer;
        }
        .card-img-top {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .card-buttons {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .card-container {
            display: flex;
            flex-wrap: wrap;
        }
        .card-container .col {
            display: flex;
        }
        .card {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="pagetitle">
        <h1>Workshops</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(action('App\Http\Controllers\LMSDashboardController@getView')); ?>">LMS</a></li>
                <li class="breadcrumb-item active" href="<?php echo e(action('App\Http\Controllers\WorkshopController@index')); ?>">Workshop</li>
            </ol>
        </nav>
    </div>

    <div class="container-fluid mt-4">
        <?php if(\App\Http\Controllers\AccountController::permission() == 1): ?>
            <button class="btn btn-success mb-4" data-bs-toggle="modal" data-bs-target="#addWorkshopModal">Add Workshop</button>
        <?php endif; ?>
        <div class="row card-container">
            <?php $__currentLoopData = $workshops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workshop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 position-relative">
                    <div class="card mb-4 shadow-sm" onclick="window.location='<?php echo e(route('workshop.show', ['workshop_id' => $workshop->workshop_id])); ?>'">
                        <?php if($workshop->workshop_image_url): ?>
                            <img class="card-img-top" src="<?php echo e($workshop->workshop_image_url); ?>" alt="Workshop Image">
                        <?php else: ?>
                            <img class="card-img-top" src="<?php echo e(asset('assets/img/workshop-default.jpg')); ?>" alt="Default Workshop Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e(Str::limit($workshop->workshop_title, 30)); ?></h5>
                            <p class="card-text"><?php echo e(Str::limit($workshop->workshop_description, 100)); ?></p>
                            <?php if(\App\Http\Controllers\AccountController::permission() == 1): ?>
                                <div class="card-buttons">
                                    <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editWorkshopModal-<?php echo e($workshop->workshop_id); ?>" onclick="event.stopPropagation();">Edit</button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Edit Workshop Modal -->
                <div class="modal fade" id="editWorkshopModal-<?php echo e($workshop->workshop_id); ?>" tabindex="-1" aria-labelledby="editWorkshopModalLabel-<?php echo e($workshop->workshop_id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editWorkshopModalLabel-<?php echo e($workshop->workshop_id); ?>">Edit Workshop</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('workshop.update', ['workshop_id' => $workshop->workshop_id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="mb-3">
                                        <label for="workshop_title_<?php echo e($workshop->workshop_id); ?>" class="form-label">Workshop Title</label>
                                        <input type="text" class="form-control" id="workshop_title_<?php echo e($workshop->workshop_id); ?>" name="workshop_title" value="<?php echo e($workshop->workshop_title); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="workshop_description_<?php echo e($workshop->workshop_id); ?>" class="form-label">Workshop Description</label>
                                        <textarea class="form-control" id="workshop_description_<?php echo e($workshop->workshop_id); ?>" name="workshop_description" rows="3" required><?php echo e($workshop->workshop_description); ?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="workshop_image_<?php echo e($workshop->workshop_id); ?>" class="form-label">Workshop Image</label>
                                        <input type="file" class="form-control" id="workshop_image_<?php echo e($workshop->workshop_id); ?>" name="workshop_image">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Add Workshop Modal -->
    <div class="modal fade" id="addWorkshopModal" tabindex="-1" aria-labelledby="addWorkshopModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addWorkshopModalLabel">Add Workshop</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('workshop.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="workshop_title" class="form-label">Workshop Title</label>
                            <input type="text" class="form-control" id="workshop_title" name="workshop_title" required>
                        </div>
                        <div class="mb-3">
                            <label for="workshop_description" class="form-label">Workshop Description</label>
                            <textarea class="form-control" id="workshop_description" name="workshop_description" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="workshop_img_url" class="form-label">Workshop Image URL</label>
                            <input type="text" class="form-control" id="workshop_image_url" name="workshop_image_url">
                        </div>
                        <div class="mb-3">
                            <label for="workshop_image" class="form-label">Workshop Image</label>
                            <input type="file" class="form-control" id="workshop_image" name="workshop_image">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main-lms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/lms/workshop/index.blade.php ENDPATH**/ ?>