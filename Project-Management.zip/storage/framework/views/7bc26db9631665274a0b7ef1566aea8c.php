<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <style>
        /* Tắt chọn văn bản cho một phần cụ thể */
        .no-select {
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }

        /* Đổi màu nền khi hover trên hàng */
        .table-hover tr:hover {
            /* background-color: #f5f5f5; */
            cursor: pointer;
            /* Thay đổi con trỏ để chỉ định hàng có thể nhấp được */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="pagetitle">
        <h1>Portfolio</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="#">Portfolio</a></li>
            </ol>
        </nav>
    </div>
    <div class="card p-2 border rounded-4">
        <div class="card-body">
            <table id="table" class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th class="text-center" data-field="employee_code">Employee Code</th>
                        <th class="text-center" data-field="photo">Photo</th>
                        <th data-field="full_name">Full Name</th>
                        <th data-field="en_name">English Name</th>
                        <th data-field="department">Department</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sql; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-href="<?php echo e(route('portfolio.id', ['id' => $item->employee_code])); ?>">
                            <td class="text-center"><?php echo e($item->employee_id); ?></td>
                            <td class="text-center"><?php echo e($item->employee_code); ?></td>
                            <td class="text-center">
                                <img src="<?php echo e($item->photoExists ? asset($item->photo) : asset('assets/img/avt.png')); ?>"
                                    style="width: 50px; height: 50px; border-radius: 50%" alt="">
                            </td>
                            <td><?php echo e($item->last_name . ' ' . $item->first_name); ?></td>
                            <td><?php echo e($item->en_name); ?></td>
                            <td><?php echo e($item->department_name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            var table = $('#table').DataTable({
                language: {
                    search: ""
                },
                initComplete: function(settings, json) {
                    $('.dt-search').addClass('input-group');
                    $('.dt-search').prepend(`<button class="input-group-text bg-secondary-subtle border-secondary-subtle rounded-start-4">
                                <i class="bi bi-search"></i>
                            </button>`)
                },
                responsive: true
            });

            // Sự kiện click trên hàng
            $('#table').on('click', 'tr', function() {
                var url = $(this).data('href');
                if (url) {
                    window.location.href = url;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/portfolio/portfolio.blade.php ENDPATH**/ ?>