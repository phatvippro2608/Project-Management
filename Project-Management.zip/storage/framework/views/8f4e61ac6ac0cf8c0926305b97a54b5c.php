<?php $__env->startSection('head'); ?>
    <style>
        .workshop-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container mt-4">
        <div class="card mb-4 shadow-sm">
            <?php if($workshop->workshop_image_url): ?>
                <img class="workshop-image" src="<?php echo e($workshop->workshop_image_url); ?>" alt="Workshop Image">
            <?php else: ?>
                <img class="workshop-image" src="<?php echo e(asset('assets/img/workshop-default.jpg')); ?>" alt="Default Workshop Image">
            <?php endif; ?>
            <div class="card-body">
                <h1 class="card-title"><?php echo e($workshop->workshop_title); ?></h1>
                <p class="card-text"><?php echo e($workshop->workshop_description); ?></p>
                <p class="card-text"><?php echo e($workshop->workshop_content); ?></p>
                <button class="btn btn-primary" onclick="window.location='<?php echo e(route('lms.live', ['workshop_id' => $workshop->workshop_id])); ?>'">Click here</button>
                <a href="<?php echo e(route('workshop.index')); ?>" class="btn btn-primary">Back to Workshops</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main-lms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/lms/workshop/show.blade.php ENDPATH**/ ?>