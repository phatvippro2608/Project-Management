<?php $__env->startSection('contents'); ?>
    <div class="pagetitle">
        <h1>Employees</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Employees</li>
            </ol>
        </nav>
    </div>
    <div class="border rounded-4 p-1 bg-white">
        <div class="card mb-0 shadow-none">
            <div class="card-header fw-semibold text-white border-3 border-secondary-subtle rounded-4" style="background: var(--clr-1)">Personal Details</div>
            <div class="card-body p-3">
                <div class="row">
                    <div class="col-6">
                        <div class="row mb-3">
                            <label for="inputText" class="col-sm-4 col-form-label">Employee Code</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control employee_code" name="" value="<?php echo e($data_employee->employee_code); ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputText" class="col-sm-4 col-form-label">First Name</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control first_name" name="" value="<?php echo e($data_employee->first_name); ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputText" class="col-sm-4 col-form-label">Last Name</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control last_name" name="" value="<?php echo e($data_employee->last_name); ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputText" class="col-sm-4 col-form-label">English Name</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control en_name" name="" value="<?php echo e($data_employee->en_name); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <fieldset class="row mb-3">
                            <legend class="col-form-label col-sm-4 pt-0">Gender</legend>
                            <div class="col-sm-8">
                                <div class="d-flex">
                                    <div class="form-check me-3">
                                        <input class="form-check-input" type="radio" name="gender" id="male" value="0" <?php if($data_employee->gender == 0): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="male">
                                            Male
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="gender" id="female" value="1" <?php if($data_employee->gender == 1): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="female">
                                            Female
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="row mb-3">
                            <legend class="col-form-label col-sm-4 pt-0">Marital Status</legend>
                            <div class="col-sm-8">
                                <div class="d-flex">
                                    <div class="form-check me-3">
                                        <input class="form-check-input" type="radio" name="marital_status" id="single" value="Single" <?php if($data_employee->marital_status == 'Single'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="single">
                                            Single
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="marital_status" id="married" value="Married" <?php if($data_employee->marital_status == 'Married'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="married">
                                            Married
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="row mb-3">
                            <legend class="col-form-label col-sm-4 pt-0">Military Service</legend>
                            <div class="col-sm-8">
                                <div class="d-flex">
                                    <div class="form-check me-3">
                                        <input class="form-check-input" type="radio" name="military_service" id="Done" value="Done" <?php if($data_employee->military_service == 'Done'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="Done">
                                            Done
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="military_service" id="Noyet" value="No yet" <?php if($data_employee->military_service == 'No yet'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="Noyet">
                                            No yet
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <div class="row mb-3">
                            <label for="inputDate" class="col-sm-4 col-form-label">Date of Birth</label>
                            <div class="col-sm-8">
                                <input type="date" class="form-control date_of_birth" name="" value="<?php echo e(\Carbon\Carbon::parse($data_employee->date_of_birth)->format('Y-m-d')); ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-4 col-form-label">Nation</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" value="<?php echo e($data_employee->national); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-0 shadow-none">
            <div class="card-header fw-semibold text-white border-3 border-secondary-subtle rounded-4" style="background: var(--clr-1)"> Personal Contacts</div>
            <div class="card-body p-3">
                <div class="row mb-3">
                    <label for="inputText" class="col-sm-4 col-form-label">Phone Number</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control phone_number" name="" value="<?php echo e($data_contact->phone_number); ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-4 col-form-label">Passport Number</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control passport_number" name="" value="<?php echo e($data_passport ? $data_passport->passport_number : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputText" class="col-sm-4 col-form-label">Passport place of Issue</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control passport_place_issue" name="" value="<?php echo e($data_passport ? $data_passport->passport_place_issue : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">Passport date of Issue</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control passport_issue_date" name="" value="<?php echo e($data_passport ?  \Carbon\Carbon::parse($data_passport->passport_issue_date)->format('Y-m-d') : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">Passport date of Expiry</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control passport_expiry_date" name="" value="<?php echo e($data_passport ?  \Carbon\Carbon::parse($data_passport->passport_expiry_date)->format('Y-m-d') : ''); ?>}}">
                    </div>
                </div>
                <div class="row mb-4">
                    <label for="inputText" class="col-sm-4 col-form-label">Citizen identity Card Number</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control cic_number" name="" value="<?php echo e($data_contact->cic_number); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <label for="inputText" class="col-sm-4 col-form-label">Citizen place of issue</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control cic_place_issue" name="" value="<?php echo e($data_contact->cic_place_issue); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">CIC date of Issue</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control cic_issue_date" name="" value="<?php echo e(\Carbon\Carbon::parse($data_contact->cic_issue_date)->format('Y-m-d')); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">CIC date of Expiry</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control cic_expiry_date" name="" value="<?php echo e(\Carbon\Carbon::parse($data_contact->cic_expiry_date)->format('Y-m-d')); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <label for="inputText" class="col-sm-4 col-form-label">Place of Residence</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control current_residence" name="" value="<?php echo e($data_contact->current_residence); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <label for="inputText" class="col-sm-4 col-form-label">Permanent Address</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control permanent_address" name="" value="<?php echo e($data_contact->permanent_address); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">Medical Check-up Date</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control medical_checkup_date" name=""
                               value="<?php echo e($data_medical_checkup && $data_medical_checkup->isNotEmpty() ? $data_medical_checkup->first()->medical_checkup_issue_date : ''); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-0 shadow-none">
            <div class="card-header fw-semibold text-white border-3 border-secondary-subtle rounded-4" style="background: var(--clr-1)"> Personal Job Detail</div>
            <div class="card-body p-3">
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Job Title</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobTitles'][$data_job_detail->id_job_title]) ? $jobdetails['jobTitles'][$data_job_detail->id_job_title - 1 ]->job_title : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Job Category</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" data="" value="<?php echo e(isset($jobdetails['jobCategories'][$data_job_detail->id_job_category-1]) ? $jobdetails['jobCategories'][$data_job_detail->id_job_category - 1 ]->job_category_name : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Position</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobPositions'][$data_job_detail->id_job_position]) ? $jobdetails['jobPositions'][$data_job_detail->id_job_position - 1]->position_name : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Team</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobTeams'][$data_job_detail->id_job_team-12]) ? $jobdetails['jobTeams'][$data_job_detail->id_job_team - 12]->team_name : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Level</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobLevels'][$data_job_detail->id_job_level]) ? $jobdetails['jobLevels'][$data_job_detail->id_job_level - 1]->level_name : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputEmail" class="col-sm-4 col-form-label">Email</label>
                    <div class="col-sm-8">
                        <input type="email" class="form-control email" name="" value="<?php echo e($email); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">Start Date</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control start_date" name="" value="<?php echo e(\Carbon\Carbon::parse($data_job_detail->start_date)->format('Y-m-d')); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-4 col-form-label">End Date</label>
                    <div class="col-sm-8">
                        <input type="date" class="form-control end_date" name="" value="<?php echo e(\Carbon\Carbon::parse($data_job_detail->end_date)->format('Y-m-d')); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Type of Contract</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobTypeContract'][$data_job_detail->id_job_type_contract]) ? $jobdetails['jobTypeContract'][$data_job_detail->id_job_type_contract - 1]->type_contract_name : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Country</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobCountry'][$data_job_detail->id_job_country]) ? $jobdetails['jobCountry'][$data_job_detail->id_job_country - 1]->country_name : ''); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-4 col-form-label">Location</label>
                    <div class="col-sm-8">
                        <input type="text" name="" id="" class="form-control" value="<?php echo e(isset($jobdetails['jobLocation'][$data_job_detail->id_job_location-3]) ? $jobdetails['jobLocation'][$data_job_detail->id_job_location - 3]->location_name : ''); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-0">
            <div class="col-6">
                <div class="card mb-0 shadow-none">
                    <div class="card-header fw-semibold text-white rounded-start-4 rounded-end-0" style="background: var(--clr-1)">Personal Profile</div>
                    <div class="card-body p-3">
                        <table class="table table-hover table-borderless">
                            <thead>
                            <tr>
                                <th>No.</th>
                                <th>Filename</th>
                            </tr>
                            </thead>
                            <tbody class="cv-list">
                            <?php
                                $dataCV = json_decode($data_cv);
                            ?>
                            <?php if($dataCV): ?>
                                <?php $__currentLoopData = $dataCV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><a target="_blank" href="<?php echo e(asset('/uploads/' . $data_employee->id_employee . '/' . $item)); ?>"><?php echo e($item); ?></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card mb-0 shadow-none">
                    <div class="card-header fw-semibold text-white rounded-end-4 rounded-start-0" style="background: var(--clr-1)">Medical CheckUp</div>
                    <div class="card-body p-3 table-overflow">
                        <table class="table table-hover table-borderless">
                            <thead>
                            <tr>
                                <th>No.</th>
                                <th>Filename</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody class="medical_list">
                                <?php
                                    $dataMedical = json_decode($data_medical_checkup);
                                ?>
                                <?php if($dataMedical): ?>
                                    <?php $__currentLoopData = $dataMedical; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><a target="_blank" href="<?php echo e(asset('/uploads/' . $item->id_employee . '/' . $item->medical_checkup_file)); ?>"><?php echo e($item->medical_checkup_file); ?></a></td>
                                            <td><?php echo e($item->medical_checkup_issue_date); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card mb-0 shadow-none">
                    <div class="card-header fw-semibold text-white border-3 border-secondary-subtle rounded-4" style="background: var(--clr-1)">Certificates</div>
                    <div class="card-body p-3 table-overflow">
                        <table class="table table-hover table-borderless">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">File Name</th>
                                <th scope="col">Type</th>
                                <th scope="col">Expiry Date</th>
                            </tr>
                            </thead>
                            <tbody class="certificate_list">
                                <?php
                                    $dataCertificate = json_decode($data_certificate);
                                ?>
                                <?php if($dataCertificate): ?>
                                    <?php $__currentLoopData = $dataCertificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><a target="_blank" href="<?php echo e(asset('/uploads/' . $item->id_employee . '/' . $item->certificate)); ?>"><?php echo e($item->certificate); ?></a></td>
                                            <td><?php echo e($item->certificate_type_name); ?></td>
                                            <td><?php echo e($item->end_date_certificate); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        const elements = document.querySelectorAll('input, select, textarea');
        elements.forEach(element => {
            element.disabled = true;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/employees/info.blade.php ENDPATH**/ ?>