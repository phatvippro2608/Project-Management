<?php $__env->startSection('head'); ?>
    <style>
        .custom-checkbox-lg {
            width: 22px;
            height: 22px;
            margin-bottom: 1px;
            margin-right: 5px;
        }
        .custom-checkbox-lg input[type="checkbox"] {
            width: 22px;
            height: 22px;
            margin-bottom: 1px;
            margin-right: 5px;
        }
        .hover-details{
            text-decoration: none;
            color: var(--bs-primary);
        }
        .hover-details:hover{
            text-decoration: underline;
            opacity: 1;
            color: var(--bs-primary);
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
    <div class="pagetitle">
        <h1>Team List</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Team List</li>
            </ol>
        </nav>
    </div>

    <a href="<?php echo e(action('App\Http\Controllers\TeamController@getView')); ?>" class="btn btn-primary my-3 me-2">
        <div class="d-flex align-items-center">
                <i class="bi bi-reply-fill pe-2"></i>
                Back
        </div>
    </a>

    <div class="btn btn-primary my-3 btn-add">
        <div class="d-flex align-items-center">
            <i class="bi bi-file-earmark-plus-fill pe-2"></i>
            Select Employee
        </div>
    </div>

    <div class="card border rounded-4 p-2">
        <div class="card-body">
            <div class="table-responsive">
                <table id="teamListTable" class="table table-hover table-borderless">
                    <thead class="table-light">
                    <tr>
                        <th class="text-center" style="width: 112px">Avatar</th>
                        <th class="text-center">Employee Code</th>
                        <th class="text-center">Full Name</th>
                        <th class="text-center">Email</th>
                        <th class="text-center">Username</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Position in team</th>

                    </tr>
                    </thead>
                    <tbody class="account-list">
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="account-item">
                            <td class="text-center">
                                <div class="d-flex align-items-center justify-content-center">
                                    <img src="<?php echo e($item->photo); ?>" alt="" onerror="this.onerror=null;this.src='<?php echo e(asset('assets/img/not-found.svg')); ?>';" class="account-photo2 rounded-circle p-0 m-0">
                                </div>
                            </td>
                            <td class="text-center">
                                <?php echo e($item->employee_code); ?>

                            </td>
                            <td class="text-left">
                                <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?>

                            </td>
                            <td class="text-left">
                                <?php echo e($item->email); ?>

                            </td>
                            <td class="text-center">
                                <?php echo e($item->username); ?>

                            </td>
                            <td class="text-center">
                                <?php if($status[$item->status] == 'Offine'): ?>
                                    <i class="bi bi-circle-fill account-status offine"></i>
                                <?php elseif($status[$item->status] == 'Locked'): ?>
                                    <i class="bi bi-circle-fill account-status" style="color:red;"></i>
                                <?php else: ?>
                                    <i class="bi bi-circle-fill account-status"></i>
                                <?php endif; ?>

                                <?php echo e($status[$item->status]); ?>

                            </td>
                            <td class="text-center">
                                <?php if(!empty($item->position_name)): ?><?php echo e($item->position_name); ?><?php else: ?> <?php echo e("Member"); ?> <?php endif; ?>
                            </td>












                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade md1 modal-xl">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-bold"></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 1rem">


                            <div class="table-responsive">
                                <table id="eListTable" class="table table-hover table-borderless">
                                    <thead class="table-light">
                                    <tr>
                                        <th class="text-center" style="width: 112px">Avatar</th>
                                        <th class="text-center">Employee Code</th>
                                        <th class="text-center">Full Name</th>
                                        <th class="text-center">Email</th>
                                        <th class="text-center">Position</th>
                                        <th class="text-center" data-orderable="false"><input type="checkbox" name="" id="" class="custom-checkbox-lg check-all"></th>
                                    </tr>
                                    </thead>
                                    <tbody class="account-list">
                                    <?php $__currentLoopData = $all_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="account-item">
                                            <td class="text-center">
                                                <div class="d-flex align-items-center justify-content-center">
                                                    <img src="<?php echo e($item->photo); ?>" alt="" onerror="this.onerror=null;this.src='<?php echo e(asset('assets/img/not-found.svg')); ?>';" class="account-photo2 rounded-circle p-0 m-0">
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <?php echo e($item->employee_code); ?>

                                            </td>
                                            <td class="text-left">
                                                <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?>

                                            </td>
                                            <td class="text-left">
                                                <?php echo e($item->email); ?>

                                            </td>
                                            <td class="text-left">
                                                <select class="form-select position" data="<?php echo e($item->employee_id); ?>">
                                                    <option value="100">Member</option>
                                                    <?php $__currentLoopData = $team_positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($position->team_permission !== 100): ?>
                                                            <option value="<?php echo e($position->team_permission); ?>" <?php if($item->team_permission==$position->team_permission): ?> selected <?php endif; ?>><?php echo e($position->position_name); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="text-center">
                                                <input type="checkbox" class="custom-checkbox-lg check-item" data="<?php echo e($item->employee_id); ?>" <?php if($item->isAtTeam): ?> checked <?php endif; ?>>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>




            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var table = $('#teamListTable').DataTable({
            language: { search: "" },
            lengthMenu: [
                [10, 30, 50, 100, -1],
                [10, 30, 50, 100, "All"]
            ],
            pageLength: <?php echo e(env('ITEM_PER_PAGE')); ?>,
            order:
        [1,'asc']
            ,
            initComplete: function (settings, json) {
                $('.dt-search').addClass('input-group');

            },
            responsive: true
        });
        var table2 = $('#eListTable').DataTable({
            language: { search: "" },
            lengthMenu: [
                [10, 30, 50, 100, -1],
                [10, 30, 50, 100, "All"]
            ],
            pageLength: -1,
            initComplete: function (settings, json) {
                $('.dt-search').addClass('input-group');
                $('.dt-search').prepend(`<button class="input-group-text bg-secondary-subtle border-secondary-subtle rounded-start-4">
                                <i class="bi bi-search"></i>
                            </button>`)
            },
            responsive: true
        });



        $('.btn-add').click(function () {
            $('.md1 .modal-title').text('Select Employee');
            $('.md1').modal('show');

            $('.at1').click(function () {
                if ($('.name1').val().trim() === '') {
                    alert('Please enter a team name.');
                    return;
                }

                $.ajax({
                    url: `<?php echo e(action('App\Http\Controllers\TeamController@add')); ?>`,
                    type: "PUT",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        'team_name': $('.name1').val(),
                        'status': $('.name2').val(),
                        'team_description': $('.name3').val(),
                    },
                    success: function (result) {
                        result = JSON.parse(result);
                        if (result.status === 200) {
                            toastr.success(result.message, "Successfully");
                            setTimeout(function () {
                                window.location.reload();
                            }, 300);
                        } else {
                            toastr.error(result.message, "Failed");
                        }
                    }
                });
            });
        });
        $('.check-all').change(function () {
            $('.check-item').prop('checked', $('.check-all').prop('checked')).trigger('change');
        });

        $('.check-item').change(function (){
            let employee_id = $(this).attr('data');
            let team_permission = $('select.form-select.position[data="' + employee_id + '"]').val();
            console.log(employee_id)
            console.log(team_permission)
            $.ajax({
                url: `<?php echo e(action('App\Http\Controllers\TeamDetailsController@update')); ?>`,
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    'employee_id': employee_id,
                    'team_id': <?php echo e($teams->team_id); ?>,
                    'team_permission': team_permission,
                    'checked': $(this).prop('checked')?1:0
                },
                success: function (result) {
                    result = JSON.parse(result);
                    if (result.status === 200) {
                        toastr.success(result.message, "Successfully");
                    } else {
                        toastr.error(result.message, "Failed");
                    }
                }
            });
        })

        $('.md1').on('hidden.bs.modal', function () {
            window.location.reload();
        });

        $('.position').change(function (){
            let employee_id = $(this).attr('data');
            let team_permission = $(this).val();
            $.ajax({
                url: `<?php echo e(action('App\Http\Controllers\TeamDetailsController@updatePosition')); ?>`,
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    'employee_id': employee_id,
                    'team_id': <?php echo e($teams->team_id); ?>,
                    'team_permission': team_permission,
                },
                success: function (result) {
                    result = JSON.parse(result);
                    if (result.status === 200) {
                        toastr.success(result.message, "Successfully");
                    } else {
                        toastr.error(result.message, "Failed");
                    }
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/project-employee/team-details/team-details.blade.php ENDPATH**/ ?>