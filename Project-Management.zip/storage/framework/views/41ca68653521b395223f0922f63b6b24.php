<?php $__env->startSection('contents'); ?>
    <section class="section dashboard">
        <div class="row gx-5">
            <div class="col-lg-12">
                <div class="row">
                    <h4 class="fw-bold mb-3"><i class="bi bi-bar-chart-line"> </i><?php echo e(__('messages.overview')); ?></h4>

                    <div class="col-xxl-3 col-xl-4 col-md-6">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e(__('messages.department')); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-list-task"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php if($department_c): ?>
                                                <?php echo e($department_c); ?>

                                            <?php else: ?>
                                                0
                                            <?php endif; ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-4 col-md-6">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e(__('messages.employee')); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($em_c); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-4 col-md-6">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e(__('messages.team')); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($team_c); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-4 col-md-6">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e(__('messages.project')); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-briefcase"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($project_c); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-4 col-md-6">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e(__('messages.task')); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-list-task"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php if($task_c): ?>
                                                <?php echo e($task_c); ?>

                                            <?php else: ?>
                                                0
                                            <?php endif; ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-4 col-md-6">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e(__('messages.subtask')); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-list-task"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php if($sub_c): ?>
                                                <?php echo e($sub_c); ?>

                                            <?php else: ?>
                                                0
                                            <?php endif; ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="row gy-3">
            <div class="col-xl-8 col-lg-6">
                <h4 class="fw-bold mb-3"><i class="bi bi-clock-history"> </i><?php echo e(__('messages.recent_project')); ?></h4>
                <div class="border-0 rounded-4 shadow bg-white" style="min-height: 300px">
                    <div class="p-3">
                        <div class="row">
                            <?php $__currentLoopData = $recent_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12">
                                    <a href="../project/<?php echo e($item->project_id); ?>" class="card card-hover shadow-none">
                                        <div class="card-body p-2">
                                            <div class="d-flex align-items-center">
                                                <div
                                                    class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-briefcase"></i>
                                                </div>
                                                <div class="ps-3">
                                                    <h6 class="fw-bolder"><?php echo e($item->project_name); ?></h6>
                                                    <span
                                                        class="text-success small pt-1 fw-bold"><?php echo e($item->created_at); ?></span>
                                                    <span class="text-muted small pt-2 ps-1"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6">
                <h4 class="fw-bold mb-3"><i class="bi bi-list-task"> </i><?php echo e(__('messages.todolist')); ?></h4>
                <div class="border-0 rounded-4 shadow bg-white" style="min-height: 300px">
                    <div class="p-3">
                        <div class="card bg-white shadow-none">
                            <div class="card-header">
                                <div class="card-title"><?php echo e(\App\Http\Controllers\AccountController::getNow()); ?></div>
                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->state == 1): ?>
                                    <a href="<?php echo e(route('root').'/task/'.$item->task_id); ?>"  class="card card-hover shadow-none m-0">
                                        <div class="card-body p-3">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div
                                                    class="todo-event-<?php echo e($item->task_id); ?> d-flex align-items-center text-success">
                                                    <h5 class="m-0 ms-2"><?php echo e($item->task_name); ?></h5>
                                                </div>
                                                <div class="todo-time">
                                                    <input
                                                        type="checkbox"
                                                        class="update-todo rounded-checkbox"
                                                        id="<?php echo e($item->task_id); ?>"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                <?php elseif($item->state == 2): ?>
                                    <a href="<?php echo e(route('root').'/task/'.$item->task_id); ?>" class="card card-hover shadow-none m-0">
                                        <div class="card-body p-3">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div
                                                    class="todo-event-<?php echo e($item->task_id); ?> d-flex align-items-center text-success text-decoration-line-through">
                                                    <h5 class="m-0 ms-2"><?php echo e($item->task_name); ?></h5>
                                                </div>
                                                <div class="todo-time">
                                                    <input
                                                        type="checkbox"
                                                        class="update-todo rounded-checkbox"
                                                        id="<?php echo e($item->task_id); ?>"
                                                        checked
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('.update-todo').change(function () {
            var task_id = $(this).attr('id');
            console.log($(this).attr('checked'))
            $(this).prop('checked') ? $('.todo-event-' + task_id).addClass('text-decoration-line-through') : $('.todo-event-' + task_id).removeClass('text-decoration-line-through')
            $.ajax({
                url: `<?php echo e(action('App\Http\Controllers\DashboardController@UpdateTodo')); ?>`,
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    'task_id': task_id,
                },
                success: function (result) {
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL-PROJECT\Project-Management\resources\views/auth/dashboard/dashboard.blade.php ENDPATH**/ ?>