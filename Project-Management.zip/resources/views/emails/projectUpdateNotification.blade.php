<!DOCTYPE html>
<html>
<head>
    <title>Cập nhật công việc từ MyXTeam</title>
</head>
<body>
<h1>Cập nhật công việc từ MyXTeam</h1>
<p>{!! $details['message'] !!}</p>
</body>
</html>
